package br.com.Aula_1;

import java.util.Scanner;

public class ParImpar {

	public static void main(String[] args) {
		
		Scanner tec = new Scanner(System.in);
		
		int numero;
		
		System.out.print("Informe um numero: ");
		numero = tec.nextInt();
		System.out.println("O valor informado foi: " + numero);
		
		if (numero % 2 == 0) {
			System.out.println("Par");
		}else {
			System.out.println("Impar");
		}
		
		
	}

}
