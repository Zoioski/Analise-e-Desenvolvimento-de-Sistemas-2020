package br.com.Aula_1;

import java.util.Scanner;

public class SalarioDependente {

	public static void main(String[] args) {
		
		Scanner tec = new Scanner(System.in);
		
		String nome;
		int qtdDependente;
		double salario, reajuste;
		
		System.out.print("Informe o nome do funcionario : ");
		nome = tec.next();
		System.out.print("Informe a quantidade de dependentes: ");
		qtdDependente = tec.nextInt();
		System.out.print("Informe o salario do funcionario R$ : ");
		salario = tec.nextDouble();
		
		System.out.println("------------------");
		switch (qtdDependente) {
		case 0:
			reajuste = salario + (salario * 2 / 100);
			break;
		case 1:
			reajuste = salario + (salario * 5 / 100);
			break;
		case 2: case 3: case 4:
			reajuste = salario + (salario * 8 / 100);
			break;

		default:
			reajuste = salario + (salario * 10 / 100);
			break;
		}
		
		System.out.println("O funcionario " + nome + ", tera seu salario reajustado para R$" + reajuste);

	}

}
