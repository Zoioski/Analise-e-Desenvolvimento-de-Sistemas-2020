package br.com.Aula_1;

public class Vetor {

	public static void main(String[] args) {
		
		int[] numero = {12, 32, 55, 67};
		int[] idade = new int[5];
		
		idade[0] = 29;
		idade[1] = 25;
		idade[2] = 9;
		idade[3] = 49;
		idade[4] = 36;
		
		
		
		System.out.println(idade[2]);
		System.out.println(idade.length);
		
		for (int i = 0; i < idade.length; i++) {
			System.out.println("Valor da posicao: " + i + " : " + idade[i]);
		}
	
		

	}

}
