package br.com.Aula_1;

import java.util.Scanner;

public class MaioridadePenal {

	public static void main(String[] args) {
		/*
		 * Desenvolva um algoritmo que apresente a maioridade
		 * atrav�s de um valor informado pelo usu�rio, a ser
		 * atribuido em uma variavel do tipo INT e apresente
		 * as seguintes condicoes:
		 *	Se a idade for maior que 18 apresente a mensagem "Maior de idade";
		 *	Caso a idade seja menor que 18, apresente "Ainda � menor de idade";
		 */
		Scanner tec = new Scanner(System.in);
		
		int numero;
		
		System.out.print("Informe sua idade: ");
		numero = tec.nextInt();
		System.out.println("O valor informado foi: " + numero);
		
		if (numero >= 18) {
			System.out.println("Maior de Idade");
		}else {
			System.out.println("Ainda e menor de idade");
		}
		
		

	}
}
