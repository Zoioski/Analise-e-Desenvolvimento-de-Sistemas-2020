package br.com.Aula_1;

import java.util.Scanner;

public class Voto_java {

	public static void main(String[] args) {
		
		Scanner tec = new Scanner(System.in);
		
		final int ano = 2019;
		int idade, nascimento;
		
		System.out.print("Informe o ano de nascimento: ");
		nascimento = tec.nextInt();
		
		idade = ano - nascimento;
		
		if (idade < 16) {
			System.out.println("Voce eh menor e no pode votar");
			
		}else if (idade < 18) {
			System.out.println("Voce eh menor de idade, mas seu voto eh opcional");
			
		}else if (idade >= 18 && idade < 65) {
			System.out.println("Voce eh de maior e seu voto eh obrigatorio");
			
		}else {
			System.out.println("Seu voto eh opcional");
		}

	}

}
