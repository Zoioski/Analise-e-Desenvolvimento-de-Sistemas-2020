package br.com.Aula_1;

public class DoWhileTeste {

	public static void main(String[] args) {
		
		/**
		 * Laco de repeticao com WHILE
		 */
		int valor = 0;
		while(valor <= 5) {
			System.out.println("Valor: " + valor);
			valor ++;			
		}

		System.out.println("Valor vale " + valor);
		System.out.println("----------------");
		
		/**
		 * Laco de repeticao com DO WHILE
		 */
		
		int numero = 0;
		do {
			System.out.println("Numero: " + numero);
			numero++;
			
		} while (numero <=5);

		System.out.println("--------------");
		System.out.println("Numero vale: " + numero);
		
		/**
		 * Laco de repeticao com FOR
		 */
		
		for (int i = 0; i < 5; i++) {
			System.out.println("i vale :" + i);
			
		}
		System.out.println("----------");
		int qtd;
		for (qtd = 0; qtd < 5; qtd++) {
			System.out.println("Qtd vale: " + qtd);
			
		}
		
	}

}
