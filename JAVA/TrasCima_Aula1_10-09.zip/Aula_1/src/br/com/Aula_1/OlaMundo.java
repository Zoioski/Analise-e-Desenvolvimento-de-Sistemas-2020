package br.com.Aula_1;

public class OlaMundo {
// variaveis padrao do java : int float boolean char var
	public static void main(String[] args) {
		System.out.println("Ola Mundo!!!");

		int idade = 29;
		String nome;
		
		System.out.println("Tenho " + idade + " anos.");
		nome = "Gustavo";
		System.out.println(nome);
		final String sobrenome = "de Assis";
		System.out.println(nome + "" + sobrenome);
		
		String aluno = "Jose";
		float nota1 = 7.5f,  nota2 = 8f, nota3 = 5.5f;
		float media = (nota1 + nota2 + nota3) / 4;
		
		System.out.printf("Aluno obteve : %.2f\n", media);
		if (media >= 7) {
			System.out.println("APROVADO");
		}
		else {
			System.out.println("REPROVADO");
		}
		/*
		 * Operadores Aritmeticos ( igualzinho o C )
		 * + - * / %
		 * Operadores Relacionais
		 * > < >= <= == !=
		 */
		
		
		
	}

}
