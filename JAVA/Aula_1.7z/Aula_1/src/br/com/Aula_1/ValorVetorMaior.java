package br.com.Aula_1;

import java.util.Scanner;

public class ValorVetorMaior {

	public static void main(String[] args) {
		
		Scanner tec = new Scanner(System.in);
		
		double[] Valor = new double[4];
		String Opcao;
		int qtd = 0;
		double maior = 0;
		double menor = 0;
		
		
		do {
			
			System.out.print("Informe um valor: ");
			Valor[qtd] = tec.nextDouble();
			
			if(Valor[qtd] > maior) {
				maior = Valor[qtd];
			}
			if (qtd == 0) {
				menor = Valor[qtd];
			}
			if(Valor[qtd] < menor) {
				menor = Valor[qtd];
			}
			
			qtd++;
			
			System.out.print("Deseja informar mais algum valor ? ");
			Opcao = tec.next();
			
		} while (Opcao.equals("s") && qtd < 4);
		
		for (int i = 0; i < Valor.length; i++) {
			System.out.println("Valor da posicao : " + i + " : " + Valor[i]);
		}
		System.out.println("Maior valor informado foi :" + maior);
		System.out.println("Menor valor informado foi :" + menor);
		
		tec.close();
		}
		
		
	}
