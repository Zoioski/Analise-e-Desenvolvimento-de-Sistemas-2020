package br.com.Aula_1;

import java.util.Scanner;

public class Notas {

	public static void main(String[] args) {
		
		
		Scanner in = new Scanner(System.in);
		
		double notas = 0;
		double soma = 0;
		double media;
		int qtdNotas = 0;
		String continuar;
		
		do {
			System.out.println("Informe uma nota: ");
			notas = in.nextDouble();
			
			soma = soma + notas;
			
			qtdNotas++;
			
			System.out.println("Deseja informar mais uma nota ? [s/n]");
			continuar = in.next();
			
		} while (continuar.equalsIgnoreCase("s"));
		
		media = soma / qtdNotas;
		
		System.out.println("Foram informadas " + qtdNotas + " notas ");
		System.out.println("A media foi : " + media);
			
		
	}

}
