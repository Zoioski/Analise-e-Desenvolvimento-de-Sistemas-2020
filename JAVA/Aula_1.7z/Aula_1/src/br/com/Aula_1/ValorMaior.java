package br.com.Aula_1;

import java.util.Scanner;

public class ValorMaior {

	public static void main(String[] args) {

		Scanner tec = new Scanner(System.in);
		
		int valor;
		int repeticao = 1;
		int soma = 0;
		int maior = 0;
		
		while (repeticao <= 5) {
			System.out.print("Informe o " + repeticao + "� valor:");
			valor = tec.nextInt();
			
			soma = soma + valor;
			
			if (valor >= maior) {
				maior = valor;
				
			}
			
			repeticao++;
			
		}
		
		System.out.println("A soma dos valores da: " + soma);
		System.out.println("O maior valor informado foi: " + maior);
		
		
		/**
		 * Desenvolva um algoritmo JAVA que receb 4 notas de aluno e realize o calculo da media e a o final
		 * apresente a maior nota.
		 * Se media >= 7 : APROVADO
		 * Se media >= 4.5 : EXAME
		 * Se media < 4.5 : REPROVADO
		 */
		
		
		
	}

}
