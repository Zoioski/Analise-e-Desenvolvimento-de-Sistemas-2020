package br.com.Aula_1;

import java.util.Scanner;

public class Boletim {

	public static void main(String[] args) {
		
		Scanner tec = new Scanner(System.in);
		
		double[] Valor = new double[4];
		int qtd = 0;
		double maior = 0;
		double menor = 0;
		double media = 0;
		String Opcao;
		double soma = 0; 
		String Aluno;
		
		System.out.print("Informe o nome do aluno: ");
		Aluno = tec.next();
		
		do {
			
			System.out.print("Informe a nota : ");
			Valor[qtd] = tec.nextDouble();
			
			if(Valor[qtd] > maior) {
				maior = Valor[qtd];
			}
			if (qtd == 0) {
				menor = Valor[qtd];
			}
			if(Valor[qtd] < menor) {
				menor = Valor[qtd];
			}
			
			soma += Valor[qtd];
			
			qtd++;
			
			System.out.print("Deseja informar mais alguma nota ? ");
			Opcao = tec.next();
			
		} while (Opcao.equals("s") && qtd < 4);
		
		
		media = soma/Valor.length;
		
		for (int i = 0; i < qtd; i++) {
			System.out.println("Nota " + (i+1) +"� :"  + Valor[i]);
		}
		System.out.println("Caro Aluno: " + Aluno);
		System.out.printf("M�dia : %.2f\n", media);
		System.out.println("Maior Nota : " + maior);
		System.out.println("Menor Nota : " + menor);
		
		if (media >= 7) {
			System.out.println("--------------------------");
			System.out.println("---------APROVADO---------");
			System.out.println("--------------------------");
		}else if (media >= 4.5 && media < 7) {
			System.out.println("--------------------------");
			System.out.println("------DA PRA SALVAR-------");
			System.out.println("--------------------------");
			
		}
		else{
			System.out.println("--------------------------");
			System.out.println("--------REPROVADO---------");
			System.out.println("--------------------------");
			
		}
		
		tec.close();
		}
		
		
	}
