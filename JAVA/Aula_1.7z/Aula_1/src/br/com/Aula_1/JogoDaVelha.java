package br.com.Aula_1;

import java.util.Scanner;

public class JogoDaVelha {
	
	static char[][] tabuleiro = new char[3][3];	
	static char jogadorAtual = 'x';
	
	//fsaaaaaaaaaaa
	static char getJogadorAtual()
	{
		return jogadorAtual;
	}
	
	//Desenha o tabuleiro vazio
	static void iniciaTabuleiro()
	{
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				tabuleiro[i][j] = '-';				
			}
		}
	}
	
	//Imprime o tabuleiro
	static void imprimeTabuleiro() 
	{
		System.out.println("--------------");
		
		for (int i = 0; i < 3; i++) {
			System.out.print("| ");
			for (int j = 0; j < 3; j++) {
				System.out.print(tabuleiro[i][j] + " | ");				
			}
			System.out.println();
			System.out.println("--------------");			
		}
	}
	
	//Passa por todas as celulas do tabuleiro e se uma estiver vazia (contem char '-')
	static boolean isTabuleiroCompleto()
	{
		boolean isFull = true;
		
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (tabuleiro[i][j] == '-') {
					isFull = false;
				}				
			}
		}
		
		return isFull;
	}
	
	//Retorna verdadeiro se existe um vencedor, senao false.
	//Isso chama as outras func�oes de verificacao de vitoria para verificar o quadro
	static boolean existeVencedor()
	{
		return (existeVencedorLinha() || existeVendedorColuna() || existeVencedorDiagonais());
	}
	
	//Percorre as linhas para verificar se existe um vencedor
	static boolean existeVencedorLinha()
	{
		for (int i = 0; i < 3; i++) {
			if (verificaVencedor(tabuleiro[i][0], tabuleiro[i][1], tabuleiro[i][2]) == true) {
				return true;
			}
		}
		return false;
	}
	
	//Percorre as colunas para verificar se existe um vencedor
	static boolean existeVendedorColuna()
	{
		for (int i = 0; i < 3; i++) {
			if (verificaVencedor(tabuleiro[0][i], tabuleiro[1][i], tabuleiro[2][i]) == true) {
				return true;
			}
		}
		return false;
	}
	
	//Percorre as diagonais para verificar se existe um vencedor
	static boolean existeVencedorDiagonais()
	{
		return((verificaVencedor(tabuleiro[0][0], tabuleiro[1][1], tabuleiro[2][2]) == true) || (verificaVencedor(tabuleiro[0][2],
				tabuleiro[1][1], tabuleiro[2][0]) == true));
	}
		
	//Verifica se todos os 3 valores sao iguais (nao estao vazios) entao ha um vencedor.
	static boolean verificaVencedor(char c1, char c2, char c3) {
		return ((c1 != '-') && (c1 == c2) && (c2 == c3));
	}
	
	//Muda de jogador atual.
	static void mudaJogador()
	{
		if (jogadorAtual == 'x') {
			jogadorAtual = 'o';
		}
		else {
			jogadorAtual = 'x';
		}
	}
	
	//Marca a jogada do jogador atual.
	static boolean marcaJogada(int row, int col) {
		
		if ((row >= 0) && (row <3)) {
			if ((col >= 0) && (col < 3)) {
				if (tabuleiro[row][col] == '-') {
					tabuleiro[row][col] = jogadorAtual;
					mudaJogador();
					return true;
				}
			}
		}
		return false;
	}
	
	public static void main(String[] args)
	{
		
		iniciaTabuleiro();
		System.out.println("Jogo da Velha!");
		Scanner scan = new Scanner(System.in);
		do
		{
			imprimeTabuleiro();
			int linha;
			int coluna;
			do
			{
				System.out.println("Jogador \"" + getJogadorAtual() +
						"\", digite a linha [enter]) e coluna [enter] "
						+ "que voce deseja marcar!");
				linha = scan.nextInt()-1;
				coluna = scan.nextInt()-1;
			}
			while(!marcaJogada(linha, coluna));
			//mudaJogador();
			
		}
		
		//laco do jogo
		while(!existeVencedor() && !isTabuleiroCompleto());
		if (isTabuleiroCompleto() && !existeVencedor())
		{
			System.out.println("Velha (Empate)!");
		}
		else
		{
			imprimeTabuleiro();
			mudaJogador();
			System.out.println("Jogador \"" + Character.toUpperCase(getJogadorAtual())+ "Voce Venceu!");
		}
		scan.close();
		
		
	}

	
	

}
