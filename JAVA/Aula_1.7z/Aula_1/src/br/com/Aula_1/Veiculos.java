package br.com.Aula_1;

import java.awt.SystemColor;
import java.util.Scanner;

public class Veiculos {

	public static void main(String[] args) {
		
		Scanner tec = new Scanner(System.in);
		
		int opcao;
		
		System.out.println("----- Veiculos -----");
		System.out.println("1) Carro");
		System.out.println("2) Moto");
		System.out.println("3) Caminhao");
		System.out.println("4) Bicicleta");
		System.out.println("Informe a opcao desejada: ");
		opcao = tec.nextInt();
		
		switch (opcao) {
		case 1:
			System.out.println("-- Carro ---");
			System.out.println("Fiat");
			System.out.println("GM");
			System.out.println("VW");
			System.out.println("BMW");
			break;
			
		case 2:
			System.out.println("--- Moto ---");
			System.out.println("Yamaha");
			System.out.println("Honda");
			System.out.println("Suzuki");
			System.out.println("Chinerai");
			break;
			
		case 3:
			System.out.println("--- Caminhao ---");
			System.out.println("Mercedes");
			System.out.println("Ford");
			System.out.println("Volvo");
			break;
			
		case 4:
			System.out.println("--- Bicicleta ---");
			System.out.println("Caloi");
			System.out.println("Sundown");
			System.out.println("SOUL");
			System.out.println("Mormai");
			break;

		default:
			System.out.println("Opcao invalida !!!");
			break;
		}

	}

}
