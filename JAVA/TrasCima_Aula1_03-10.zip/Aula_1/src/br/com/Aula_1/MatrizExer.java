package br.com.Aula_1;

public class MatrizExer {

	public static void main(String[] args) {

		/*
		 * Percorer a matriz e impimir os valore armazenados nas posicoes;
		 * Verificar o maior e o meno valor da matriz;
		 * Calcular a media dos valore armazenados;
		 * Calcular a soma dos valores da primeir coluna;
		 * Multiplicar os valores da segunda coluna;
		 * A soma de todos os valores;
		 */
		
		double maior = 0;
		double menor = 0;
		double media = 0;
		double soma = 0;
		double multi = 0;
		
		int valor[][] = {
				{3, 8, 6},	
				{9, 2 ,15},
				{12, 5, 7}
					
		};
		
		for (int i = 0; i < valor.length; i++) {
			for (int j = 0; j < valor.length; j++) {
				System.out.print("|" + valor[i][j] + "|");
				
				if(valor[i][j] > maior) {
					maior = valor[i][j];
				}
				if (valor[i][j] == 0) {
					menor = valor[i][j];
				}
				if(valor[i][j] < menor) {
					menor = valor[i][j];
				}
				
				soma += valor[i][j];
				
			}
		}
		
		media = soma/valor.length;
		
		System.out.println("Maior : " + maior);
		System.out.println("Menor : " + menor);
		System.out.println("Media : " + media);
		
		
	}

}
