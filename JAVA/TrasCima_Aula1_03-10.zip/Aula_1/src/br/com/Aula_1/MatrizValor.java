package br.com.Aula_1;

public class MatrizValor {

	public static void main(String[] args) {

		String[][] nome = new String[3][4];
		
		nome[0][0] = "Jonatam";
		nome[0][1] = "Maria";
		nome[0][2] = "Eva";
		nome[0][3] = "Meeee";
		
		nome[2][0] = "20";
		nome[2][1] = "10";
		nome[2][2] = "50";
		nome[2][3] = "111";
		
		nome[1][0] = "M";
		nome[1][1] = "F";
		nome[1][2] = "F";
		nome[1][3] = "?";
		
		for (int i = 0; i < nome.length + 1; i++) {
			System.out.println();
			for (int j = 0; j < nome.length; j++) {
				System.out.printf(nome[j][i] + " / ");
			}
		}
		
	}

}
