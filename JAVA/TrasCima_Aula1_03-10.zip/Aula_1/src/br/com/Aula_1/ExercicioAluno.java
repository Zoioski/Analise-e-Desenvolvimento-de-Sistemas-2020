package br.com.Aula_1;

import java.util.Scanner;

public class ExercicioAluno {

	public static void main(String[] args) {
		//Clase scanner: entrada de dados pelo teclado
		//instanciando um novo objeto para a classe Scanner		
		Scanner tec = new Scanner(System.in);
		
		double nota1, nota2, nota3, nota4;
		double media = 0;
		double maior = 0;
		String nome;
		
		System.out.println("Informe o nome do aluno: ");
		nome = tec.next();
		System.out.println("Informe  a nota 1 : ");
		nota1 = tec.nextDouble();
		System.out.println("Informe  a nota 2 : ");
		nota2 = tec.nextDouble();
		System.out.println("Informe  a nota 3 : ");
		nota3 = tec.nextDouble();
		System.out.println("Informe  a nota 4 : ");
		nota4 = tec.nextDouble();
		
		media = (nota1 + nota2 + nota3 + nota4)/4;
		
		System.out.println("-----BOLETIM DO ALUNO-----");
		System.out.println("Caro aluno : "+ nome);
		System.out.println("Suas nota foram : ");
		System.out.println("Nota 1 : "+ nota1 );
		System.out.println("Nota 2 : "+ nota2 );
		System.out.println("Nota 3 : "+ nota3 );
		System.out.println("Nota 4 : "+ nota4 );
		System.out.println("--------------------------\n");
		System.out.println("Sua media final foi : " + media);
		System.out.println("--------------------------");
		
			if (nota1 >= maior) {
				maior = nota1;				
			}
			
			if (nota2 >= maior) {
				maior = nota4;				
			}
			
			if (nota3 >= maior) {
				maior = nota4;				
			}
			
			if (nota4 >= maior) {
				maior = nota4;				
			}
		

			if (media >= 7) {
				System.out.println("--------------------------");
				System.out.println("---------APROVADO---------");
				System.out.println("Sua maior nota foi: " + maior);
				System.out.println("--------------------------");
			}else if (media >= 4.5 && media < 7) {
				System.out.println("--------------------------");
				System.out.println("---------EM EXAME---------");
				System.out.println("Sua maior nota foi: " + maior);
				System.out.println("--------------------------");
				
			}
			else{
				System.out.println("--------------------------");
				System.out.println("--------REPROVADO---------");
				System.out.println("Sua maior nota foi: " + maior);
				System.out.println("--------------------------");
				
			}
		

	}

}
