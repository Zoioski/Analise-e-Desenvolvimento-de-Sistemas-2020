package br.com.Aula_1;

import java.util.Scanner;

public class ValoVetor {

	public static void main(String[] args) {
		
		Scanner tec = new Scanner(System.in);
		
		double[] Valor = new double[4];
		String Opcao;
		int qtd = 0;
		
		do {
			
			System.out.print("Informe um valor: ");
			Valor[qtd] = tec.nextDouble();
			
			qtd++;
			
			System.out.print("Deseja informar mais algum valor ? ");
			Opcao = tec.next();
			
		} while (Opcao.equals("s") && qtd < 4);
		
		for (int i = 0; i < Valor.length; i++) {
			System.out.println("Valor da posicao : " + i + " : " + Valor[i]);
		}
		
		tec.close();
		}
		
		
	}
