package principal;

import model.bean.Usuario;
import model.dao.UsuarioDAO;

public class TesteUsuarioBD {

	public static void main(String[] args) {

	/*	Usuario u = new Usuario();
		u.setId(2);
		u.setNome("Norberto Kultz Clone");*/
		
		UsuarioDAO uDAO = new UsuarioDAO();
		//uDAO.insere(u);
		
		System.out.println("***** RELA��O DOS USU�RIOS*****");
		for(Usuario usuario : uDAO.mostraUsuarios()) {
			System.out.println(usuario);
		}
		
		Usuario u = new Usuario();
		u.setId(2);
		u.setNome("Norberto Kultz TRANGENICO");
		
		uDAO.altera(u);
		
		System.out.println("***** RELA��O DOS USU�RIOS*****");
		for(Usuario usuario : uDAO.mostraUsuarios()) {
			System.out.println(usuario);
		}
		
		
	}

}
