package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import model.bean.Usuario;
import model.connection.ConnectionFactory;

public class UsuarioDAO {

	public void insere(Usuario usuario) {

		Connection con = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;

		try {
			String sql = "INSERT INTO usuario (id, nome) VALUES (?, ?)";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, usuario.getId());
			stmt.setString(2, usuario.getNome());

			stmt.executeUpdate();

			System.out.println("Registro " + usuario + " salvo com sucesso!");
		} catch (SQLException ex) {
			System.out.println("Erro ao tentar salvar " + ex);
			Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			ConnectionFactory.closeConnection(con, stmt);
		}
	}
	
	public List<Usuario> mostraUsuarios(){
		
		Connection con = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Usuario> usuarios = new ArrayList<Usuario>();
		
		try {
			stmt = con.prepareStatement("SELECT * FROM usuario");
			
			rs = stmt.executeQuery();
			
			while(rs.next()) {
				Usuario usuario = new Usuario();
				
				usuario.setId(rs.getInt("id"));
				usuario.setNome(rs.getString("nome"));
				usuarios.add(usuario);
			}
		}catch (SQLException ex) {
			System.out.println("Erro ao tentar salvar " + ex);
			Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			ConnectionFactory.closeConnection(con, stmt);
		}
		
		return usuarios;
		
	}
	
	public void altera(Usuario usuario) {
		
		Connection con = ConnectionFactory.getConnection();
		PreparedStatement stmt = null;
		
		try {
			String sql = "UPDATE usuario SET nome = ? WHERE id = ?";
			stmt = con.prepareStatement(sql);
			stmt.setString(1, usuario.getNome());
			stmt.setInt(2, usuario.getId());

			stmt.executeUpdate();

			System.out.println("Registro " + usuario + " alterado com sucesso!");
		} catch (SQLException ex) {
			System.out.println("Erro ao tentar salvar " + ex);
			Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			ConnectionFactory.closeConnection(con, stmt);
		}
		
		
		
	}

}
